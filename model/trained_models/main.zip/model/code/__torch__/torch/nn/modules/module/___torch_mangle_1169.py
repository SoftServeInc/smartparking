op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  _conv_stem : __torch__.torch.nn.modules.module.___torch_mangle_821.Module
  _bn0 : __torch__.torch.nn.modules.module.___torch_mangle_822.Module
  _blocks : __torch__.torch.nn.modules.module.___torch_mangle_1162.Module
  _conv_head : __torch__.torch.nn.modules.module.___torch_mangle_1164.Module
  _bn1 : __torch__.torch.nn.modules.module.___torch_mangle_1165.Module
  _avg_pooling : __torch__.torch.nn.modules.module.___torch_mangle_1166.Module
  _dropout : __torch__.torch.nn.modules.module.___torch_mangle_1167.Module
  _swish : __torch__.torch.nn.modules.module.___torch_mangle_1168.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1169.Module,
    input: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    _0 = getattr(self._blocks, "22")
    _1 = getattr(self._blocks, "21")
    _2 = getattr(self._blocks, "20")
    _3 = getattr(self._blocks, "19")
    _4 = getattr(self._blocks, "18")
    _5 = getattr(self._blocks, "17")
    _6 = getattr(self._blocks, "16")
    _7 = getattr(self._blocks, "15")
    _8 = getattr(self._blocks, "14")
    _9 = getattr(self._blocks, "13")
    _10 = getattr(self._blocks, "12")
    _11 = getattr(self._blocks, "11")
    _12 = getattr(self._blocks, "10")
    _13 = getattr(self._blocks, "9")
    _14 = getattr(self._blocks, "8")
    _15 = getattr(self._blocks, "7")
    _16 = getattr(self._blocks, "6")
    _17 = getattr(self._blocks, "5")
    _18 = self._swish
    _19 = (self._bn0).forward((self._conv_stem).forward(input, ), )
    _20 = getattr(self._blocks, "1")
    _21 = (getattr(self._blocks, "0")).forward((_18).forward(_19, ), )
    _22 = getattr(self._blocks, "3")
    _23 = (getattr(self._blocks, "2")).forward((_20).forward(_21, ), )
    _24 = (getattr(self._blocks, "4")).forward((_22).forward(_23, ), )
    _25 = (_16).forward((_17).forward(_24, ), )
    _26 = (_15).forward(_25, )
    _27 = (_13).forward((_14).forward(_26, ), )
    _28 = (_11).forward((_12).forward(_27, ), )
    _29 = (_9).forward((_10).forward(_28, ), )
    _30 = (_7).forward((_8).forward(_29, ), )
    _31 = (_4).forward((_5).forward((_6).forward(_30, ), ), )
    _32 = (_1).forward((_2).forward((_3).forward(_31, ), ), )
    _33 = ((_0).forward(_32, ), _30, _26, _24)
    return _33
