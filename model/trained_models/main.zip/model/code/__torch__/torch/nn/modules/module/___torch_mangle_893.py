op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", ]
  training : bool
  weight : Tensor
  static_padding : __torch__.torch.nn.modules.module.___torch_mangle_892.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_893.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.weight
    _1 = (self.static_padding).forward()
    input = torch._convolution(argument_1, _0, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True)
    return input
