op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1130.Module,
    argument_1: Tensor) -> Tensor:
    input = torch.mul(argument_1, torch.sigmoid(argument_1))
    return input
  def forward1(self: __torch__.torch.nn.modules.module.___torch_mangle_1130.Module,
    argument_1: Tensor) -> Tensor:
    input = torch.mul(argument_1, torch.sigmoid(argument_1))
    return input
  def forward2(self: __torch__.torch.nn.modules.module.___torch_mangle_1130.Module,
    argument_1: Tensor) -> Tensor:
    x = torch.mul(argument_1, torch.sigmoid(argument_1))
    return x
