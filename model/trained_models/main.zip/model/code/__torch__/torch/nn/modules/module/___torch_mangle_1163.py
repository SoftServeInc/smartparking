op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
