op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  encoder : __torch__.torch.nn.modules.module.___torch_mangle_1169.Module
  decoder : __torch__.torch.nn.modules.module.___torch_mangle_1223.Module
  segmentation_head : __torch__.torch.nn.modules.module.___torch_mangle_1228.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1229.Module,
    input: Tensor) -> Tensor:
    _0 = self.segmentation_head
    _1 = self.decoder
    _2, _3, _4, _5, = (self.encoder).forward(input, )
    _6 = (_0).forward((_1).forward(_2, _3, _4, _5, ), )
    return _6
