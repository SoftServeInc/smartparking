op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  _expand_conv : __torch__.torch.nn.modules.module.___torch_mangle_1028.Module
  _bn0 : __torch__.torch.nn.modules.module.___torch_mangle_1029.Module
  _depthwise_conv : __torch__.torch.nn.modules.module.___torch_mangle_1031.Module
  _bn1 : __torch__.torch.nn.modules.module.___torch_mangle_1032.Module
  _se_reduce : __torch__.torch.nn.modules.module.___torch_mangle_1034.Module
  _se_expand : __torch__.torch.nn.modules.module.___torch_mangle_1036.Module
  _project_conv : __torch__.torch.nn.modules.module.___torch_mangle_1038.Module
  _bn2 : __torch__.torch.nn.modules.module.___torch_mangle_1039.Module
  _swish : __torch__.torch.nn.modules.module.___torch_mangle_1040.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1041.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self._bn2
    _1 = self._project_conv
    _2 = self._se_expand
    _3 = self._se_reduce
    _4 = self._bn1
    _5 = self._depthwise_conv
    _6 = self._swish
    _7 = self._bn0
    _8 = (self._expand_conv).forward(argument_1, )
    _9 = (_5).forward((_6).forward((_7).forward(_8, ), ), )
    _10 = (_6).forward1((_4).forward(_9, ), )
    x = torch.adaptive_avg_pool2d(_10, [1, 1])
    _11 = (_2).forward((_6).forward2((_3).forward(x, ), ), )
    x0 = torch.mul(torch.sigmoid(_11), _10)
    x1 = torch.add((_0).forward((_1).forward(x0, ), ), argument_1, alpha=1)
    return x1
