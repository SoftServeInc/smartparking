op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  skip_conv : __torch__.torch.nn.modules.module.___torch_mangle_1171.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1172.Module,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    _0 = self.skip_conv
    _1 = ops.prim.NumToTensor(torch.size(argument_1, 2))
    _2 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _3 = torch.mul(torch.to(_1, 6, False, False, None), torch.detach(_2))
    _4 = torch.floor(torch.to(_3, 6, False, False, None))
    _5 = ops.prim.NumToTensor(torch.size(argument_1, 3))
    _6 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _7 = torch.mul(torch.to(_5, 6, False, False, None), torch.detach(_6))
    _8 = torch.floor(torch.to(_7, 6, False, False, None))
    x = torch.upsample_nearest2d(argument_1, [int(_4), int(_8)])
    input = torch.add(x, (_0).forward(argument_2, ), alpha=1)
    return input
