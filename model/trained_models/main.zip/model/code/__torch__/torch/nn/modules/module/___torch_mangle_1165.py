op_version_set = 1
class Module(Module):
  __parameters__ = ["bias", "weight", ]
  training : bool
  bias : Tensor
  weight : Tensor
  running_mean : Tensor
  running_var : Tensor
  num_batches_tracked : Tensor
