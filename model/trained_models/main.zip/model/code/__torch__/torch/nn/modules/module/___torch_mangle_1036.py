op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", "bias", ]
  training : bool
  weight : Tensor
  bias : Tensor
  static_padding : __torch__.torch.nn.modules.module.___torch_mangle_1035.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1036.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.bias
    _1 = self.weight
    _2 = (self.static_padding).forward()
    x_squeezed = torch._convolution(argument_1, _1, _0, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True)
    return x_squeezed
