op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.module.___torch_mangle_1224.Module
  __annotations__["1"] = __torch__.torch.nn.modules.module.___torch_mangle_1225.Module
  __annotations__["2"] = __torch__.torch.nn.modules.module.___torch_mangle_1227.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1228.Module,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "2")
    _1 = getattr(self, "1")
    _2 = (getattr(self, "0")).forward(argument_1, )
    _3 = (_1).forward(_2, )
    _4 = (_0).forward()
    return _3
