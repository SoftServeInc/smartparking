op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  _depthwise_conv : __torch__.torch.nn.modules.module.___torch_mangle_836.Module
  _bn1 : __torch__.torch.nn.modules.module.___torch_mangle_837.Module
  _se_reduce : __torch__.torch.nn.modules.module.___torch_mangle_839.Module
  _se_expand : __torch__.torch.nn.modules.module.___torch_mangle_841.Module
  _project_conv : __torch__.torch.nn.modules.module.___torch_mangle_843.Module
  _bn2 : __torch__.torch.nn.modules.module.___torch_mangle_844.Module
  _swish : __torch__.torch.nn.modules.module.___torch_mangle_845.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_846.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self._bn2
    _1 = self._project_conv
    _2 = self._se_expand
    _3 = self._se_reduce
    _4 = self._swish
    _5 = self._bn1
    _6 = (self._depthwise_conv).forward(argument_1, )
    _7 = (_4).forward((_5).forward(_6, ), )
    x = torch.adaptive_avg_pool2d(_7, [1, 1])
    _8 = (_2).forward((_4).forward1((_3).forward(x, ), ), )
    x0 = torch.mul(torch.sigmoid(_8), _7)
    x1 = torch.add((_0).forward((_1).forward(x0, ), ), argument_1, alpha=1)
    return x1
