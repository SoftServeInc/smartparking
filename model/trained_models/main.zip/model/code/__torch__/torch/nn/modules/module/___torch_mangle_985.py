op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_985.Module,
    argument_1: Tensor) -> Tensor:
    x = torch.constant_pad_nd(argument_1, [1, 1, 1, 1], 0.)
    return x
