op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.module.___torch_mangle_1193.Module
  __annotations__["1"] = __torch__.torch.nn.modules.module.___torch_mangle_1205.Module
  __annotations__["2"] = __torch__.torch.nn.modules.module.___torch_mangle_1212.Module
  __annotations__["3"] = __torch__.torch.nn.modules.module.___torch_mangle_1219.Module
