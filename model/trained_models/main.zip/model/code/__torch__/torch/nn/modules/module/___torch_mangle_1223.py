op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  p5 : __torch__.torch.nn.modules.module.___torch_mangle_1170.Module
  p4 : __torch__.torch.nn.modules.module.___torch_mangle_1172.Module
  p3 : __torch__.torch.nn.modules.module.___torch_mangle_1174.Module
  p2 : __torch__.torch.nn.modules.module.___torch_mangle_1176.Module
  seg_blocks : __torch__.torch.nn.modules.module.___torch_mangle_1220.Module
  merge : __torch__.torch.nn.modules.module.___torch_mangle_1221.Module
  dropout : __torch__.torch.nn.modules.module.___torch_mangle_1222.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1223.Module,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    _0 = self.dropout
    _1 = self.merge
    _2 = getattr(self.seg_blocks, "3")
    _3 = getattr(self.seg_blocks, "2")
    _4 = getattr(self.seg_blocks, "1")
    _5 = getattr(self.seg_blocks, "0")
    _6 = self.p2
    _7 = self.p3
    _8 = self.p4
    _9 = (self.p5).forward(argument_1, )
    _10 = (_8).forward(_9, argument_2, )
    _11 = (_7).forward(_10, argument_3, )
    _12 = (_6).forward(_11, argument_4, )
    _13 = (_1).forward((_5).forward(_9, ), (_4).forward(_10, ), (_3).forward(_11, ), (_2).forward(_12, ), )
    return (_0).forward(_13, )
