op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1225.Module,
    argument_1: Tensor) -> Tensor:
    _0 = ops.prim.NumToTensor(torch.size(argument_1, 2))
    _1 = torch.to(CONSTANTS.c2, torch.device("cpu"), 6, False, False, None)
    _2 = torch.mul(torch.to(_0, 6, False, False, None), torch.detach(_1))
    _3 = torch.floor(torch.to(_2, 6, False, False, None))
    _4 = ops.prim.NumToTensor(torch.size(argument_1, 3))
    _5 = torch.to(CONSTANTS.c2, torch.device("cpu"), 6, False, False, None)
    _6 = torch.mul(torch.to(_4, 6, False, False, None), torch.detach(_5))
    _7 = torch.floor(torch.to(_6, 6, False, False, None))
    _8 = torch.upsample_bilinear2d(argument_1, [int(_3), int(_7)], True)
    return _8
