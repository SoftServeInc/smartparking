op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", "bias", ]
  training : bool
  weight : Tensor
  bias : Tensor
  static_padding : __torch__.torch.nn.modules.module.___torch_mangle_1063.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1064.Module,
    x: Tensor) -> Tensor:
    _0 = self.bias
    _1 = self.weight
    _2 = (self.static_padding).forward()
    x0 = torch._convolution(x, _1, _0, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True)
    return x0
