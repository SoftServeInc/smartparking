op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  block : __torch__.torch.nn.modules.module.___torch_mangle_1190.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1191.Module,
    argument_1: Tensor) -> Tensor:
    _0 = (self.block).forward(argument_1, )
    _1 = ops.prim.NumToTensor(torch.size(_0, 2))
    _2 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _3 = torch.mul(torch.to(_1, 6, False, False, None), torch.detach(_2))
    _4 = torch.floor(torch.to(_3, 6, False, False, None))
    _5 = ops.prim.NumToTensor(torch.size(_0, 3))
    _6 = torch.to(CONSTANTS.c0, torch.device("cpu"), 6, False, False, None)
    _7 = torch.mul(torch.to(_5, 6, False, False, None), torch.detach(_6))
    _8 = torch.floor(torch.to(_7, 6, False, False, None))
    _9 = torch.upsample_bilinear2d(_0, [int(_4), int(_8)], True)
    return _9
