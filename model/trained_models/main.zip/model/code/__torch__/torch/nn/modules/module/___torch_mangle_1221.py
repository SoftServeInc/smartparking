op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_1221.Module,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor,
    argument_4: Tensor) -> Tensor:
    _0 = torch.add(argument_1, CONSTANTS.c1, alpha=1)
    _1 = torch.add(torch.add(_0, argument_2, alpha=1), argument_3, alpha=1)
    return torch.add(_1, argument_4, alpha=1)
